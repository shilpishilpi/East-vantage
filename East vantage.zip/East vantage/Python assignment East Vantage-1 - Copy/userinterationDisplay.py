def print_menu():
    print("Employee Management System Menu:")
    print("1. Add Employee")
    print("2. Remove Employee")
    print("3. Display Department Employees")
    print("4. Add Department")
    print("5. Remove Department")
    print("6. Display Departments")
    print("0. Exit")


# Example usage:
if __name__ == "__main__":
    print_menu()